autoFacebook 2.4
webelity 2013

License:
This Zen Cart modification is licensed under the GNU General Public License: http://www.gnu.org/licenses/gpl-3.0.txt 

Requirements:
Zencart 1.5.1 or Zen Cart 1.5.0 ( will also work on older versions 1.3.8 / 1.3.9 )
php 5+ 
cURL or JSON

Install:
Video instructions can be found on YouTube at: http://youtu.be/IfW42McTKyE

Additional Help can be found at: 
The Zen Cart forums @ http://www.zen-cart.com/forum/showthread.php?t=153528
